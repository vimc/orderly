data <- read.csv("data.csv")
saveRDS(data, "out.rds")
