var count = 0;

function clicked() {
	var counter = document.getElementById("counter");
	count++;
	counter.innerText = count;
}
